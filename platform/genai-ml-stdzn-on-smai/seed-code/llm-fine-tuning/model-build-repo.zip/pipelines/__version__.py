"""Metadata for the pipelines package."""

__title__ = "llama-finetuning-pipelines"
__description__ = "SageMaker Pipelines for LLaMA fine-tuning"
__version__ = "1.0.0"
__author__ = "ML Team"
__author_email__ = "ml-team@example.com"
__url__ = "https://github.com/your-org/llama-finetuning"
__license__ = "Apache-2.0"
