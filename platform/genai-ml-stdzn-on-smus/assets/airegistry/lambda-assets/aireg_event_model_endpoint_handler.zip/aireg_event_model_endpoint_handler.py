import logging
import os
import json
import boto3
import pprint

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)
table_name = os.environ.get('DYNAMODB_TABLE_NAME', 'model_registry_table')

dynamodb = boto3.resource('dynamodb')
sagemaker = boto3.client('sagemaker')
table = dynamodb.Table(table_name)

def update_model_registry(model_package_group_name, model_package_version, stage, endpoint_arn, is_deployed=True):
    # ddb update model deployment status
    try:
        _ = table.update_item(
            Key={
                'model_package_group_name': model_package_group_name,
                'model_package_version': model_package_version
            },
            UpdateExpression=f'SET {stage}.is_deployed = :val, {stage}.endpoint_arn = :arn',
            ExpressionAttributeValues={
                ':val': str(is_deployed),
                ':arn': endpoint_arn
            }
        )
    except Exception as e:
        logger.error(f"Error updating model deployment status in DDB: {e}")
        raise

def get_ddb_entry(key):
    """Retrieve an entry from DynamoDB using the provided key."""

    try:
        response = table.get_item(Key=key)
        return response.get('Item')
    except Exception as e:
        logger.error(f"Error retrieving from DynamoDB: {e}")
        return None

def get_model_details(endpoint_config_name):
    try:
        response = sagemaker.describe_endpoint_config(
            EndpointConfigName=endpoint_config_name
        )
        model_name = response['ProductionVariants'][0]['ModelName']
        response = sagemaker.describe_model(ModelName=model_name)
        model_package_arn = response['Containers'][0]['ModelPackageName']
        model_package_group_name = model_package_arn.split('/')[-2]
        model_package_version = model_package_arn.split('/')[-1]
        return model_package_group_name, model_package_version
    except Exception as e:
        logger.error(f"Error in getting model details, {e}")
        raise

def process_event(event):
    try:
        endpoint_config_name = event['detail']['EndpointConfigName']
        model_package_group_name, model_package_version = get_model_details(endpoint_config_name)
        endpoint_arn = event['detail']['EndpointArn']

        ddb_record = get_ddb_entry({'model_package_group_name': model_package_group_name, 'model_package_version': str(model_package_version)})
        current_stage = ddb_record.get('current_model_life_cycle_stage', '')
        if current_stage is not None or current_stage != '':
            update_model_registry(model_package_group_name, model_package_version, current_stage, endpoint_arn, True)
            logger.info(f"Updated endpoint ARN in model registry for {model_package_group_name} version {model_package_version}")
            return {
                'statusCode': 200,
                'body': json.dumps({
                    'message': f'Updated endpoint ARN in model registry for {model_package_group_name} version {model_package_version}'
                })
            }
        raise ValueError("Stage is empty")
    except Exception as e:
        logger.error(f"Error in updating dynamodb, {e}")
        return {
            'statusCode': 500,
            'body': json.dumps({
                'message': 'Internal server error',
                'error': str(e)
            })  
        }

def lambda_handler(event, context):
    logger.info(f"Processing event: {json.dumps(event)}")
    return process_event(event)
    ##Deployment Code Starts
