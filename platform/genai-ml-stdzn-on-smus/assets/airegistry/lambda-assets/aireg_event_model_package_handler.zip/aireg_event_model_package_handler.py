import json
import boto3
import logging
import os

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

sagemaker = boto3.client('sagemaker')
s3 = boto3.client('s3')
table_name = os.environ.get('DYNAMODB_TABLE_NAME', 'model_registry_table')
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(table_name)
# ssm = boto3.client('ssm')
# param_prod = os.environ.get('SSM_PROD', '/smus_prod')

def get_file_s3(bucket, key):
    """Fetches a file from S3 and returns its content."""

    try:
        response = s3.get_object(Bucket=bucket, Key=key)
        content = response['Body'].read().decode('utf-8')
        return content
    except Exception as e:
        logger.error(f"Error fetching file from S3: {e}")
        return None

def get_model_tags(model_package_group_name, model_package_arn):
    model_package_group_arn = f"{model_package_arn.split('/')[0]}-group/{model_package_group_name}"
    try:
        response = sagemaker.list_tags(ResourceArn=model_package_group_arn)
        tags = {}
        for tag in response['Tags']:
            tags[tag['Key']] = tag['Value']
        return tags
    except Exception as e:
        logger.error(f'Error fetching model tags from model package group: {e}')
        return {}

# def fetch_production_env():
#     try:
#         return ssm.get_parameter(Name=f'{param_prod}/project_id')['Parameter']['Value'], ssm.get_parameter(Name=f'{param_prod}/project_name')['Parameter']['Value']
#     except Exception as e:
#         logger.error(f'Error fetching parameter values {e}')
#         return None

# def create_model_package():
#     pass

def get_ddb_entry(key):
    """Retrieve an entry from DynamoDB using the provided key."""

    try:
        response = table.get_item(Key=key)
        return response.get('Item')
    except Exception as e:
        logger.error(f"Error retrieving from DynamoDB: {e}")
        return None
    
def store_model_info_to_dynamodb(model_info):
    """Store model package information to DynamoDB."""
    
    try:
        table.put_item(Item=model_info)
        logger.info(f"Successfully stored model info for {model_info['model_package_group_name']} version {model_info['model_package_version']}")
        return True
    except Exception as e:
        logger.error(f"Error storing to DynamoDB: {e}")
        return False

def get_model_package_evaluation_metrics(response):
    try:
        s3_uri = response['ModelMetrics']['ModelQuality']['Statistics']['S3Uri']
        content = get_file_s3(*s3_uri.replace('s3://', '').split('/', 1))
        evaluation_metrics = {}
        for _, metrics in json.loads(content).items():
            for metric_name, metric_value in metrics.items():
                evaluation_metrics[metric_name] = metric_value['value']
        return evaluation_metrics
    except Exception as e:
        logger.error(f"Error fetching evaluation metrics: {e}")
        return {}

def get_training_metrics_mlflow(training_job_response):
    """Fetches training job metrics from MLflow for a given training job name."""

    training_metrics = {}
    try:
        import mlflow

        mlflow.set_tracking_uri(training_job_response['Environment']['MLFLOW_TRACKING_URI'])
        # get parent run id
        s3_uri = None
        for channel in training_job_response['InputDataConfig']:
            if channel['ChannelName'] == 'mlflow':
                s3_uri = channel['DataSource']['S3DataSource']['S3Uri']
        if s3_uri is None:
            return training_metrics
        bucket, key= s3_uri.replace('s3://', '').split('/', 1)
        key += '/parent_run_id.txt'
        parent_run_id = get_file_s3(bucket, key)
        experiment_name = training_job_response['Environment']['MLFLOW_EXPERIMENT_NAME']
        runs = mlflow.search_runs(experiment_names=[experiment_name])
        train_run_id = runs[(runs['tags.mlflow.parentRunId'] == parent_run_id) & 
                            (runs['tags.mlflow.runName'].str.contains('train', na=False))].iloc[0]['run_id']
        return mlflow.get_run(train_run_id).data.metrics

    except Exception as e:
        logger.error(f"Error fetching training job metrics: {e}")
        return training_metrics

def get_training_metrics_training_job(training_job_response):
    training_metrics = {}
    if 'FinalMetricDataList' in training_job_response:
        for metric in training_job_response['FinalMetricDataList']:
            training_metrics[metric['MetricName']] = metric['Value']
    return training_metrics

def get_training_metrics(training_job_name):
    training_job_response = sagemaker.describe_training_job(TrainingJobName=training_job_name)
    training_metrics = get_training_metrics_mlflow(training_job_response)
    return training_metrics if training_metrics else get_training_metrics_training_job(training_job_response)

def get_model_package_metrics(response):
    """Extract training job metrics from the model package source URI."""

    model_package_metrics = {
        'training_metrics': {},
        'evaluation_metrics': {}
    }
    if 'SourceUri' in response:
        training_job_name = response['SourceUri'].split('/')[-1]
        model_package_metrics['training_metrics'] = get_training_metrics(training_job_name)
    model_package_metrics['evaluation_metrics'] = get_model_package_evaluation_metrics(response)
    return model_package_metrics
    
def create_model_package_record(model_package_arn, event):
    """Get all model package information including metrics and deployment details and create record for DDB."""
    try:
        
        response = sagemaker.describe_model_package(ModelPackageName=model_package_arn)

        # fetch existing entry for the existing stages details
        model_package_group_name = response.get('ModelPackageGroupName')
        model_package_version = str(response.get('ModelPackageVersion'))
        prev_dev_stage, prev_prod_stage = {}, {}

        if previous_record:=get_ddb_entry({'model_package_group_name': model_package_group_name, 'model_package_version': str(model_package_version)}):
            logger.info(f"Entry already exists for {model_package_group_name} version {model_package_version}")
            prev_dev_stage, prev_prod_stage = previous_record['development'], previous_record['production']

        record = {
            'model_package_group_name': response.get('ModelPackageGroupName'),
            'model_package_arn': response.get('ModelPackageArn'),
            'model_package_version': str(response.get('ModelPackageVersion')),
            'created_at': str(response.get('CreationTime')),
            'model_package_description': response.get('ModelPackageDescription', ''),
            'source_uri': response.get('SourceUri', ''),
            'development': prev_dev_stage,
            'production': prev_prod_stage,
            'current_model_life_cycle_stage': '',
            # 'model_origin': {
            #     'aws_account': event['account'],
            #     'aws_region': event['region'],
            # }
        }

        # get model tags
        record['tags'] = get_model_tags(model_package_group_name, model_package_arn)
        # Extract model metrics
        model_package_metrics = get_model_package_metrics(response)
        for metric_type, metrics in model_package_metrics.items():
            for metric_name, metric_value in metrics.items():
                model_package_metrics[metric_type][metric_name] = str(metric_value)

        record['model_metrics'] = model_package_metrics

        # Extract model life cycle stage
        if 'ModelLifeCycle' in response:
            stage = response['ModelLifeCycle']['Stage'].lower()
            record['current_model_life_cycle_stage'] = stage
            record[stage]['status'] = response['ModelLifeCycle']['StageStatus']
            record[stage]['description'] = response['ModelLifeCycle'].get('StageDescription', '')
            if stage == 'development':
                # prefilling with the env, where the model was created
                record[stage]['deployment_env'] = {
                    'sagemaker_project_id': record['tags'].get('sagemaker:project-id'),
                    'sagemaker_domain_id': record['tags'].get('AmazonDataZoneDomain'),
                    'sagemaker_project_name': record['tags'].get('sagemaker:project-name')
                }
            elif stage == 'production' and prev_prod_stage == {}:
                record[stage]['deployment_env'] = {
                    'sagemaker_domain_id': '',
                    'sagemaker_project_id': '',
                    'sagemaker_project_name': ''
                }
        
        return record
    
    except Exception as e:
        logger.error(f"Error fetching model package details: {e}")
        return {}


def process_sagemaker_event(event):
    """Process SageMaker event based on event type."""
    
    # first check if the AI Registry (DDB) is already in sync
    model_package_group_name = event['detail']['ModelPackageGroupName']
    model_package_version = event['detail']['ModelPackageVersion']
    model_package_arn = event['detail']['ModelPackageArn']

    ddb_record = get_ddb_entry({'model_package_group_name': model_package_group_name, 'model_package_version': str(model_package_version)})
    record = create_model_package_record(model_package_arn, event)

    if record == ddb_record:
        print('No changes')
        logger.info("No changes detected in the model package. Skipping update.")
        return True
    
    else:
        return store_model_info_to_dynamodb(record)



def lambda_handler(event, context):
    """Lambda function handler for processing SageMaker events."""
    logger.info("Received event:")
    logger.info(event)

    try:
        # Process the event
        success = process_sagemaker_event(event)
        return {
            'statusCode': 200 if success else 500,
            'body': json.dumps({
                'message': 'Event processed successfully' if success else 'Event processing failed'
            })
        }
    except Exception as e:
        logger.error(f"Lambda handler error: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps({
                'message': 'Internal server error',
                'error': str(e)
            })
        }