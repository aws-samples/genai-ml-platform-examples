import json
import boto3
import requests
import os
import logging

# Name of the GitHub Actions workflow file that handles model deployment
# NOTE: When a deploy repository is created, it's populated with seed code from the template
#       which includes 'deploy_model_pipeline.yml'. This workflow is triggered when a 
#       SageMaker model is approved, and it handles:
#       - Creating/Updating SageMaker endpoints
#       - Model deployment and testing
#       - Other deployment-related tasks
# IMPORTANT: If you modify the workflow filename in your template or deploy repositories,
#           update this value accordingly

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)
client = boto3.client('sagemaker')

WORKFLOW_FILENAME = 'build_sagemaker_pipeline.yml'

def update_model_registry(model_package_arn, stage, status, description):
    try:
        model_lifecycle_data =  {
            "Stage": stage,
            "StageStatus": status,
            "StageDescription": description
        }
        if status not in ('Approved', 'Rejected'):
            model_approval_status = 'PendingManualApproval'
        else:
            model_approval_status = status
        return client.update_model_package(
            ModelPackageArn=model_package_arn,
            ModelLifeCycle=model_lifecycle_data,
            ModelApprovalStatus=model_approval_status
        )
    except Exception as e:
        err_message = f"error updating the model package {e}"
        logger.error(e)
        return False

def sync_sm_registry(new_record, old_record):
    # whether stage is same or not
    current_stage = new_record.get('current_model_life_cycle_stage', {}).get('S', '')
    current_stage_status = new_record.get(current_stage, {}).get('M', {}).get('status', {}).get('S', '')
    old_stage = old_record.get('current_model_life_cycle_stage', {}).get('S', '')
    old_stage_status = old_record.get(old_stage, {}).get('M', {}).get('status', {}).get('S', '')

    try:
        if current_stage == old_stage and current_stage_status == old_stage_status:
            logger.info('registries are in sync')
        elif current_stage != '':
            current_stage_description = new_record.get(current_stage, {}).get('M', {}).get('description', {}).get('S', '')
            model_package_arn = new_record['model_package_arn']['S']
            update_model_registry(model_package_arn, current_stage, current_stage_status, current_stage_description)
    except Exception as e:
        logger.error(f"Error in syncing sagemaker model registry: {str(e)}")
        

def lambda_handler(event, context):
    try:
        for record in event['Records']:
            # Extract details from event
            ddb_record = record['dynamodb']['NewImage']
            current_stage = ddb_record.get('current_model_life_cycle_stage', {}).get('S', None)
            current_stage_status = ddb_record.get(current_stage, {}).get('M', {}).get('status', {}).get('S', '')
            is_deployed = ddb_record.get(current_stage, {}).get('M', {}).get('is_deployed', {}).get('S', 'False')

            # syncing the sagemaker model registry lifecycle with ai registry updates
            sync_sm_registry(record['dynamodb']['NewImage'], record['dynamodb']['OldImage'])

            if current_stage == '' or current_stage is None or current_stage_status != "Approved" or is_deployed == 'True':
                return {
                    'statusCode': 200,
                    'body': json.dumps({
                        'message': 'Not a deployment flow.',
                    })
                }
            
            project_id = ddb_record[current_stage]['M']['deployment_env']['M'].get('sagemaker_project_id', {}).get('S', None)
            domain_id = ddb_record[current_stage]['M']['deployment_env']['M'].get('sagemaker_domain_id',{}).get('S', None)
            sagemaker_project_name = ddb_record[current_stage]['M']['deployment_env']['M'].get('sagemaker_project_name', {}).get('S', None)

            dev_project_id = None
            dev_domain_id = None
            for tag, value in ddb_record.get('tags', [])['M'].items():
                if tag == 'AmazonDataZoneDomain':
                    dev_domain_id = value['S']
                if tag in ('sagemaker:project-id', 'AmazonDataZoneProject'):
                    dev_project_id = value['S']
                    
            if not dev_project_id:
                raise ValueError("Could not find sagemaker:project-id for development in tag in model package group tags")       
            if not dev_domain_id:
                raise ValueError("Could not find AmazonDataZoneDomain for development in tag in model package group tags")
            if not project_id:
                raise ValueError("Could not find sagemaker:project-id for deployment in model package group ddb record")       
            if not domain_id:
                raise ValueError("Could not find AmazonDataZoneDomain for deployment in model package group ddb record")
            if not sagemaker_project_name:
                raise ValueError("Could not find sagemaker:project_name for deployment in model package group ddb record")
            
            
            print(f"Found project_id: {dev_project_id} and domain_id: {dev_domain_id} from model package group tags")

            # Construct repository name using organization from environment variable
            private_organization_name = os.environ.get('PRIVATE_GITHUB_ORGANIZATION')
            if not private_organization_name:
                raise ValueError("PRIVATE_GITHUB_ORGANIZATION environment variable is not set")
                
            repo_name = f"{dev_project_id}-{dev_domain_id}-deploy-repo"
            
            # Get GitHub token from Secrets Manager
            secret_name = os.environ.get('GITHUB_TOKEN_SECRET_NAME', 'smus-aiops-github-token')
            secrets_client = boto3.client('secretsmanager')
            secrets_response = secrets_client.get_secret_value(SecretId=secret_name)
            git_token = json.loads(secrets_response['SecretString'])['token']
            
            print(f"Organization name: {private_organization_name}")
            print(f"Repository name: {repo_name}")
            print(f"Workflow filename: {WORKFLOW_FILENAME}")

            # GitHub API endpoint
            url = f'https://api.github.com/repos/{private_organization_name}/{repo_name}/actions/workflows/{WORKFLOW_FILENAME}/dispatches'
            print(f"Complete GitHub API URL: {url}")

            # Headers for GitHub API
            headers = {
                'Authorization': f'token {git_token}',
                'Accept': 'application/vnd.github.v3+json',
                'Content-Type': 'application/json'
            }

            model_package_arn = ddb_record['model_package_arn']['S']
            model_package_group_name = ddb_record['model_package_group_name']['S']
            model_package_version = ddb_record['model_package_version']['S']
            # Payload for the workflow - only including the required logLevel input
            payload = {
                'ref': 'main',
                'inputs': {
                    'logLevel': 'info',
                    'model_package_arn': model_package_arn,
                    'sagemaker_project_name': sagemaker_project_name,
                    'sagemaker_project_id': project_id
                }
            }

            print(f"Triggering GitHub workflow with payload: {json.dumps(payload, indent=2)}")

            # Trigger the workflow
            github_response = requests.post(url, headers=headers, data=json.dumps(payload))
            
            print(f"Response status code: {github_response.status_code}")
            print(f"Response body: {github_response.text}")
            
            if github_response.status_code == 204:
                print(f"Successfully triggered GitHub workflow for model {model_package_group_name}")
                return {
                    'statusCode': 200,
                    'body': json.dumps({
                        'message': 'Workflow triggered successfully',
                        'project_id': project_id,
                        'domain_id': domain_id,
                        'repository': f"{private_organization_name}/{repo_name}",
                        'model_package_group': model_package_group_name
                    })
                }
            else:
                error_message = f"Failed to trigger workflow. Status code: {github_response.status_code}, Response: {github_response.text}"
                print(error_message)
                raise Exception(error_message)

    except Exception as e:
        error_message = str(e)
        print(f"Error: {error_message}")
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': error_message,
                'project_id': project_id if 'project_id' in locals() else None,
                'model_package_group': model_package_group_name if 'model_package_group_name' in locals() else None
            })
        }