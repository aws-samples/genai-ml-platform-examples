import json
import logging
import boto3
import os

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

table_name = os.environ.get('DYNAMODB_TABLE_NAME', 'project_registry_table')
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(table_name)

def store_project_info_to_dynamodb(project_info):
    """Store model package information to DynamoDB."""
    
    try:
        table.put_item(Item=project_info)
        logger.info(f"Successfully stored project info for {project_info['dz_domain_id']} version {project_info['dz_project_id']}")
        return True
    except Exception as e:
        logger.error(f"Error storing to DynamoDB: {e}")
        return False

def get_project_name(project_id, domain_id, aws_region):
    try:
        dz_client = boto3.client('datazone', region_name=aws_region)

        response = dz_client.get_project(
            domainIdentifier=domain_id,
            identifier=project_id
        )
        return response['name']
    except Exception as e:
        logger.error(f"Error describing project: {e}")
        return None

def process_event(event):
    """Process the event and return True if successful, False otherwise."""
    try:
        logger.info(f"Processing event: {json.dumps(event)}")
        # Add your event processing logic here
        event_type = event['detail']['eventName']
        if event_type == 'DeleteProject':
            dz_domain_id = event['detail']['requestParameters']['domainIdentifier']
            dz_project_id = event['detail']['requestParameters']['projectIdentifier']
            logger.info(f"Project {dz_project_id} deleted from domain {dz_domain_id}. Removing from registry.")
            table.delete_item(
                Key={
                    'dz_domain_id': dz_domain_id,
                    'dz_project_id': dz_project_id
                }
            )
            return True

        dz_domain_id = event['detail']['responseElements']['domainId']
        dz_project_id = event['detail']['responseElements']['id']
        account = event['account']
        aws_region = event['detail']['awsRegion']

        project_name = get_project_name(dz_project_id, dz_domain_id, aws_region)
        if 'prod' in project_name.lower():
            project_env_type = 'production'
        else:
            project_env_type = 'non-production'
        
        print(f"Project Name: {project_name}")
        if project_name is not None:
            logger.info(f"Creating DDB entry for project: {project_name}")
            return store_project_info_to_dynamodb({
                'dz_domain_id': dz_domain_id,
                'dz_project_id': dz_project_id,
                'dz_project_name': project_name,
                'account': account,
                'aws_region': aws_region,
                'project_env_type': project_env_type 
            })
        return True
    except Exception as e:
        logger.error(f"Error processing event: {e}")
        return False

def lambda_handler(event, context):
    try:
        # Process the event
        success = process_event(event)
        return {
            'statusCode': 200 if success else 500,
            'body': json.dumps({
                'message': 'Event processed successfully' if success else 'Event processing failed'
            })
        }
    except Exception as e:
        logger.error(f"Lambda handler error: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps({
                'message': 'Internal server error',
                'error': str(e)
            })
        }