# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0

"""Feature engineers the bank marketing dataset using AWS Data Wrangler for Glue integration."""

# Fix Debian-installed PyJWT in SageMaker containers and install mlflow
import subprocess
import sys
import os
import glob
import shutil

# Remove broken Debian PyJWT dist-info so pip can manage it
for path in glob.glob("/usr/local/lib/python*/dist-packages/PyJWT-*.dist-info"):
    shutil.rmtree(path, ignore_errors=True)
for path in glob.glob("/usr/lib/python3/dist-packages/PyJWT-*.dist-info"):
    shutil.rmtree(path, ignore_errors=True)
# Also remove the actual PyJWT module files so pip doesn't try to uninstall
for path in glob.glob("/usr/lib/python3/dist-packages/jwt"):
    shutil.rmtree(path, ignore_errors=True)
for path in glob.glob("/usr/lib/python3/dist-packages/jwt*"):
    if os.path.isdir(path):
        shutil.rmtree(path, ignore_errors=True)
    else:
        os.remove(path)

# Force reinstall PyJWT then install mlflow and sagemaker-mlflow
subprocess.check_call([sys.executable, "-m", "pip", "install", "--force-reinstall", "--no-deps", "PyJWT>=2.8.0", "-q"])
subprocess.check_call([sys.executable, "-m", "pip", "install", "awswrangler==2.16.1", "-q"])
subprocess.check_call([sys.executable, "-m", "pip", "install", "mlflow==3.4.0", "sagemaker-mlflow", "-q"])

import argparse
import logging
import pathlib
import boto3
import numpy as np
import pandas as pd
import mlflow
from time import gmtime, strftime
import awswrangler as wr
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler, OneHotEncoder

logger = logging.getLogger()
logger.setLevel(logging.INFO)
logger.addHandler(logging.StreamHandler())

# Bank marketing dataset features
numeric_features = ["age", "duration", "campaign", "pdays", "previous",
                   "emp.var.rate", "cons.price.idx", "cons.conf.idx", "euribor3m", "nr.employed"]
categorical_features = ["job", "marital", "education", "default", "housing", "loan",
                       "contact", "month", "day_of_week", "poutcome"]
label_column = "y"

if __name__ == "__main__":
    logger.info("Starting preprocessing for bank marketing dataset")
    parser = argparse.ArgumentParser()
    parser.add_argument("--database-name", type=str, required=True)
    parser.add_argument("--table-name", type=str, required=True)
    args = parser.parse_args()

    region = os.environ.get('AWS_REGION', 'us-east-1')
    boto3_session = boto3.Session(region_name=region)
    wr.config.aws_region = region

    # MLflow setup
    tracking_uri = os.environ.get("MLFLOW_TRACKING_URI")
    experiment_name = os.environ.get("MLFLOW_EXPERIMENT_NAME")
    parent_run_id = os.environ.get("MLFLOW_PARENT_RUN_ID")
    
    # Log MLflow configuration for debugging
    logger.info(f"MLflow Tracking URI: {tracking_uri}")
    logger.info(f"MLflow Experiment Name: {experiment_name}")
    logger.info(f"MLflow Parent Run ID: {parent_run_id}")

    created_parent_run_id = None
    if tracking_uri:
        suffix = strftime('%d-%H-%M-%S', gmtime())
        mlflow.set_tracking_uri(tracking_uri)
        mlflow.set_experiment(experiment_name=experiment_name if experiment_name else f"preprocessing-{suffix}")
        
        # Create parent run if not provided
        if not parent_run_id or parent_run_id == "":
            logger.info("Creating new parent MLflow run")
            parent_run = mlflow.start_run(run_name=f"pipeline-{suffix}")
            created_parent_run_id = parent_run.info.run_id
            logger.info(f"Created parent run ID: {created_parent_run_id}")
            mlflow.end_run()
            parent_run_id = created_parent_run_id
        
        # Start preprocessing run as child
        logger.info(f"Starting MLflow run with parent_run_id: {parent_run_id}")
        run = mlflow.start_run(run_name=f"preprocess-{suffix}", parent_run_id=parent_run_id)

    try:
        base_dir = "/opt/ml/processing"
        pathlib.Path(f"{base_dir}/train").mkdir(parents=True, exist_ok=True)
        pathlib.Path(f"{base_dir}/validation").mkdir(parents=True, exist_ok=True)
        pathlib.Path(f"{base_dir}/test").mkdir(parents=True, exist_ok=True)

        try:
            logger.info(f"Getting table location for {args.database_name}.{args.table_name}")
            s3_location = wr.catalog.get_table_location(
                database=args.database_name,
                table=args.table_name,
                boto3_session=boto3_session
            )
            logger.info(f"Found table S3 location: {s3_location}")

            logger.info("Reading data from S3 location")
            df = wr.s3.read_csv(
                path=s3_location,
                sep=';',
                quotechar='"',
                boto3_session=boto3_session
            )
            logger.info(f"Successfully read {len(df)} rows from S3")

        except Exception as e:
            logger.error(f"Error reading from Glue catalog: {e}")
            sys.exit(1)

        # Data preprocessing
        logger.info("Defining transformers")
        numeric_transformer = Pipeline(steps=[
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler())
        ])

        categorical_transformer = Pipeline(steps=[
            ("imputer", SimpleImputer(strategy="constant", fill_value="missing")),
            ("onehot", OneHotEncoder(handle_unknown="ignore"))
        ])

        preprocess = ColumnTransformer(transformers=[
            ("num", numeric_transformer, numeric_features),
            ("cat", categorical_transformer, categorical_features)
        ])

        # Apply transformations
        logger.info("Applying transforms")
        y = df[label_column].map({'yes': 1, 'no': 0})
        X = df[numeric_features + categorical_features]
        X_pre = preprocess.fit_transform(X)
        y_pre = y.to_numpy().reshape(len(y), 1)

        X = np.concatenate((y_pre, X_pre), axis=1)

        # Split data
        logger.info(f"Splitting {len(X)} rows into train, validation, test datasets")
        np.random.shuffle(X)
        train, validation, test = np.split(X, [int(0.7 * len(X)), int(0.85 * len(X))])

        # Log to MLflow
        if tracking_uri:
            mlflow.log_params({
                "total_rows": len(X),
                "train_rows": len(train),
                "validation_rows": len(validation),
                "test_rows": len(test),
                "database": args.database_name,
                "table": args.table_name
            })

        # Write output datasets
        logger.info(f"Writing out datasets to {base_dir}")
        pd.DataFrame(train).to_csv(f"{base_dir}/train/train.csv", header=False, index=False)
        pd.DataFrame(validation).to_csv(f"{base_dir}/validation/validation.csv", header=False, index=False)
        pd.DataFrame(test).to_csv(f"{base_dir}/test/test.csv", header=False, index=False)
        
        # Write parent run ID to output for subsequent steps
        if created_parent_run_id:
            pathlib.Path(f"{base_dir}/mlflow").mkdir(parents=True, exist_ok=True)
            with open(f"{base_dir}/mlflow/parent_run_id.txt", "w") as f:
                f.write(created_parent_run_id)
            logger.info(f"Wrote parent run ID to output: {created_parent_run_id}")

        logger.info("Data preprocessing completed successfully")

    finally:
        if tracking_uri:
            mlflow.end_run()

